import 'package:flutter/material.dart';
import 'package:math_expressions/math_expressions.dart';
class Calculator extends StatefulWidget {
  const Calculator({Key? key}) : super(key: key);

  @override
  State<Calculator> createState() => _CalculatorState();
}

class _CalculatorState extends State<Calculator> {
  List buttons=
  ["1","2","3","+",
    "4","5","6","-",
    "7","8","9","*",
    ".","0","c","/",];
  String _input = "";
  double _result=0.0;
  void _onBtnPressed(String buttonText){
    setState(() {
      if (buttonText == 'C'){
        _input = '';
        _result = 0.0;
      } else if (buttonText == '=') {
        try {
          _result = evalExpression(_input);
          _input = _result.toString();
        } catch (e) {
          _input += buttonText;
        }
      } else{
        _input+=buttonText;
      }
    });
  }

  double evalExpression(String expression) {
    try {
      Parser p = Parser();
      Expression exp = p.parse(expression);
      ContextModel cm = ContextModel();
      double evalResult = exp.evaluate(EvaluationType.REAL, cm);
      return double.parse(evalResult.toStringAsFixed(2));
    } catch (e) {
      throw Exception("Invalid expression");

    }
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        backgroundColor:(Colors.black),
        body: Column (children: [
          Expanded(
            child: Container(
              alignment: Alignment.bottomRight,
              child: Text(' _input',style:TextStyle(fontSize: 62,color: Colors.lightBlueAccent),
              ),
            ),
          ),

          Divider(),

          Expanded(
            flex: 2,
            child: Container(
                child: GridView.builder(itemCount:buttons.length,gridDelegate:SliverGridDelegateWithFixedCrossAxisCount( crossAxisCount:4),
                    itemBuilder: (context,index){
                      return ElevatedButton(

                          style:ElevatedButton.styleFrom(backgroundColor: Colors.white30,shape: CircleBorder() ),
                          onPressed:(){
                            _onBtnPressed(buttons[index]);
                          }, child: Text(buttons[index],style: TextStyle(color:Colors.yellowAccent,fontSize: 54 ),)
                      );


                    }
                )
            ),
          )
        ],
        )
    );

  }
}

